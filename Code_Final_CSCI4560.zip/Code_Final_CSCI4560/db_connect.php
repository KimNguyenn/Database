<?php

$host="localhost";
$username="root";
$user_pass="";
$database_in_use ="db1";

$mysqli = new mysqli($host, $username, $user_pass, $database_in_use);

?>