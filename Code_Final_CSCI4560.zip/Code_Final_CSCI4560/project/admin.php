<!DOCTYPE html>
<html>
    <title>
		<head> Main Page</head>
	</title>
<center>
<h2>----------------------------------------------------------------------------------</h2>
</center>	
<?php
include "db_connect.php";
include "datatable.php";
?>
<center>
<h2>----------------------------------------------------------------------------------</h2>
<h3>Click here to look at order history!</h3>
<a href="history.php"> Order History</a>
<?php echo "<br><br>"; ?>
<h2>----------------------------------------------------------------------------------</h2>
<h3>Click below to return back to main page!</h3>
<a href="index.php"> Main Page </a>
<?php echo "<br><br>"; ?>
<h2>----------------------------------------------------------------------------------</h2>
</center>
<body>

</body>
</html>